var config = {
    paths: {
		mastersoftMagento: 'Mastersoft_AddressWidget/js/mastersoft-magento',
		harmony: 'https://s3-ap-southeast-2.amazonaws.com/common.mastersoftgroup.com/scripts/harmony-current.min'
    }
};
