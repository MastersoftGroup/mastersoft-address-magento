<?php

use \Magento\Framework\Component\ComponentRegistrar;
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Mastersoft_AddressWidget', __DIR__);
